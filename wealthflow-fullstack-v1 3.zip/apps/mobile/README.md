# WealthFlow Mobile

React Native / Expo mobile app.

## Start

```bash
npm install
npm run start
```

## Local-only mode

Приложение работает без backend. Данные сохраняются в AsyncStorage.

## Backend mode

Для подключения API измени `src/api/client.ts`.
