import { Asset, ForecastSettings } from '../types';

export const demoAssets: Asset[] = [
  {
    id: 'sber',
    name: 'Сбербанк',
    ticker: 'SBER',
    type: 'STOCK',
    currency: 'RUB',
    quantity: 1200,
    avgPrice: 210,
    currentPrice: 320,
    dividendPerShare: 33,
    taxRate: 0.13,
    paymentFrequency: 'annual',
    nextPaymentDate: new Date(new Date().getFullYear() + 1, 6, 15).toISOString(),
    sector: 'Финансы',
    issuer: 'Сбербанк'
  },
  {
    id: 'ofz26238',
    name: 'ОФЗ 26238',
    ticker: 'SU26238RMFS4',
    type: 'BOND',
    currency: 'RUB',
    quantity: 1200,
    avgPrice: 860,
    currentPrice: 920,
    couponAmount: 35.4,
    nominalValue: 1000,
    taxRate: 0.13,
    paymentFrequency: 'semiannual',
    nextPaymentDate: new Date(new Date().getFullYear(), new Date().getMonth() + 2, 20).toISOString(),
    maturityDate: new Date(new Date().getFullYear() + 5, 4, 15).toISOString(),
    sector: 'Государственные облигации',
    issuer: 'Минфин'
  },
  {
    id: 'lkoh',
    name: 'Лукойл',
    ticker: 'LKOH',
    type: 'STOCK',
    currency: 'RUB',
    quantity: 85,
    avgPrice: 6200,
    currentPrice: 7600,
    dividendPerShare: 850,
    taxRate: 0.13,
    paymentFrequency: 'annual',
    nextPaymentDate: new Date(new Date().getFullYear() + 1, 0, 25).toISOString(),
    sector: 'Нефть и газ',
    issuer: 'Лукойл'
  },
  {
    id: 'cashrub',
    name: 'Свободный кэш',
    type: 'CASH',
    currency: 'RUB',
    quantity: 1,
    avgPrice: 450000,
    currentPrice: 450000,
    taxRate: 0,
    sector: 'Кэш'
  }
];

export const defaultSettings: ForecastSettings = {
  baseCurrency: 'RUB',
  monthlyContribution: 70000,
  annualReturn: 0.1,
  incomeYield: 0.08,
  inflationRate: 0.06,
  reinvestmentRate: 1,
  years: 10,
  targetCapital: 15000000,
  targetMonthlyIncome: 100000
};
