import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { demoAssets, defaultSettings } from '../data/demo';
import { Asset, ForecastSettings } from '../types';

const STORAGE_KEY = 'wealthflow_state_v1';

type AppStateValue = {
  assets: Asset[];
  settings: ForecastSettings;
  addAsset: (asset: Asset) => void;
  removeAsset: (id: string) => void;
  updateSettings: (patch: Partial<ForecastSettings>) => void;
  resetDemo: () => void;
};

const AppStateContext = createContext<AppStateValue | null>(null);

export function AppStateProvider({ children }: { children: React.ReactNode }) {
  const [assets, setAssets] = useState<Asset[]>(demoAssets);
  const [settings, setSettings] = useState<ForecastSettings>(defaultSettings);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then(raw => {
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.assets) setAssets(parsed.assets);
        if (parsed.settings) setSettings(parsed.settings);
      }
    }).finally(() => setLoaded(true));
  }, []);

  useEffect(() => {
    if (loaded) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({ assets, settings }));
  }, [assets, settings, loaded]);

  const value = useMemo<AppStateValue>(() => ({
    assets,
    settings,
    addAsset: asset => setAssets(prev => [asset, ...prev]),
    removeAsset: id => setAssets(prev => prev.filter(asset => asset.id !== id)),
    updateSettings: patch => setSettings(prev => ({ ...prev, ...patch })),
    resetDemo: () => {
      setAssets(demoAssets);
      setSettings(defaultSettings);
    }
  }), [assets, settings]);

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
}

export function useAppState() {
  const value = useContext(AppStateContext);
  if (!value) throw new Error('useAppState must be used inside AppStateProvider');
  return value;
}
