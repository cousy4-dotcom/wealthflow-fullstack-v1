import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from './theme';
import { DashboardScreen } from './screens/DashboardScreen';
import { PortfolioScreen } from './screens/PortfolioScreen';
import { CalendarScreen } from './screens/CalendarScreen';
import { ForecastScreen } from './screens/ForecastScreen';
import { SettingsScreen } from './screens/SettingsScreen';

type Tab = 'dashboard' | 'portfolio' | 'calendar' | 'forecast' | 'settings';

const tabs: Array<{ key: Tab; label: string }> = [
  { key: 'dashboard', label: 'Главная' },
  { key: 'portfolio', label: 'Портфель' },
  { key: 'calendar', label: 'Календарь' },
  { key: 'forecast', label: 'Прогноз' },
  { key: 'settings', label: 'Настройки' }
];

export function WealthFlowApp() {
  const [tab, setTab] = useState<Tab>('dashboard');

  return (
    <View style={styles.root}>
      {tab === 'dashboard' && <DashboardScreen />}
      {tab === 'portfolio' && <PortfolioScreen />}
      {tab === 'calendar' && <CalendarScreen />}
      {tab === 'forecast' && <ForecastScreen />}
      {tab === 'settings' && <SettingsScreen />}
      <View style={styles.tabbar}>
        {tabs.map(item => (
          <Pressable key={item.key} style={[styles.tab, tab === item.key && styles.active]} onPress={() => setTab(item.key)}>
            <Text style={[styles.tabText, tab === item.key && styles.activeText]}>{item.label}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  tabbar: {
    position: 'absolute',
    left: 12,
    right: 12,
    bottom: 18,
    backgroundColor: colors.primary,
    borderRadius: 22,
    flexDirection: 'row',
    padding: 6,
    gap: 4
  },
  tab: { flex: 1, paddingVertical: 10, borderRadius: 16, alignItems: 'center' },
  active: { backgroundColor: '#FFFFFF' },
  tabText: { color: '#D1D5DB', fontSize: 11, fontWeight: '700' },
  activeText: { color: colors.primary }
});
