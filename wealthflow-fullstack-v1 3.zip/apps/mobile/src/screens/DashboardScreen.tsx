import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Card } from '../components/Card';
import { MetricCard } from '../components/MetricCard';
import { PaymentRow } from '../components/PaymentRow';
import { Screen } from '../components/Screen';
import { concentrationRisk, forecastCapital, formatMoney, generateCashFlows, portfolioValue } from '../domain/finance';
import { useAppState } from '../state/AppState';
import { colors } from '../theme';

export function DashboardScreen() {
  const { assets, settings } = useAppState();
  const capital = portfolioValue(assets, settings.baseCurrency);
  const flows = generateCashFlows(assets, 12);
  const annualFlow = flows.reduce((sum, flow) => sum + flow.netAmount, 0);
  const forecast = forecastCapital(capital, settings);
  const targetYear = forecast.find(row => row.nominalCapital >= settings.targetCapital)?.year;
  const risk = concentrationRisk(assets, settings.baseCurrency);

  return (
    <Screen title="WealthFlow" subtitle="Портфель, календарь выплат и прогноз капитала в одном приложении.">
      <View style={styles.grid}>
        <MetricCard label="Капитал" value={formatMoney(capital, settings.baseCurrency)} hint={`${assets.length} активов`} />
        <MetricCard label="Cash flow / 12 мес." value={formatMoney(annualFlow, settings.baseCurrency)} hint="после налогов" />
        <MetricCard label="Через 10 лет" value={formatMoney(forecast.at(-1)?.nominalCapital ?? 0, settings.baseCurrency)} hint="номинально" />
        <MetricCard label="Пассивный доход" value={formatMoney(forecast.at(-1)?.monthlyIncome ?? 0, settings.baseCurrency)} hint="в месяц через горизонт" />
      </View>

      <Card>
        <Text style={styles.cardTitle}>Цель</Text>
        <Text style={styles.big}>{formatMoney(settings.targetCapital, settings.baseCurrency)}</Text>
        <Text style={styles.muted}>{targetYear ? `Цель может быть достигнута примерно через ${targetYear} лет` : 'По текущему сценарию цель не достигается в выбранный горизонт'}</Text>
      </Card>

      <Card>
        <Text style={styles.cardTitle}>Риск концентрации</Text>
        <Text style={styles.big}>{risk.maxWeight}%</Text>
        <Text style={styles.muted}>Крупнейшая позиция: {risk.assetName}. Уровень: {risk.level === 'high' ? 'высокий' : risk.level === 'medium' ? 'средний' : 'низкий'}.</Text>
      </Card>

      <Card>
        <Text style={styles.cardTitle}>Ближайшие выплаты</Text>
        {flows.slice(0, 5).map(flow => <PaymentRow key={flow.id} flow={flow} />)}
        {flows.length === 0 ? <Text style={styles.muted}>Выплат пока нет. Добавь дивиденды или купоны в портфель.</Text> : null}
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  cardTitle: { fontSize: 18, fontWeight: '900', color: colors.text, marginBottom: 10 },
  big: { fontSize: 26, fontWeight: '900', color: colors.text },
  muted: { color: colors.muted, marginTop: 8, lineHeight: 20 }
});
