import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Card } from '../components/Card';
import { PaymentRow } from '../components/PaymentRow';
import { Screen } from '../components/Screen';
import { formatMoney, generateCashFlows, groupedIncomeByMonth } from '../domain/finance';
import { useAppState } from '../state/AppState';
import { colors } from '../theme';

export function CalendarScreen() {
  const { assets, settings } = useAppState();
  const flows = generateCashFlows(assets, 12);
  const byMonth = groupedIncomeByMonth(flows, settings.baseCurrency);

  return (
    <Screen title="Календарь" subtitle="Будущие дивиденды, купоны, погашения и амортизации по портфелю.">
      <Card>
        <Text style={styles.cardTitle}>Доход по месяцам</Text>
        {Object.entries(byMonth).map(([month, amount]) => (
          <View key={month} style={styles.monthRow}>
            <Text style={styles.month}>{month}</Text>
            <View style={styles.barWrap}><View style={[styles.bar, { width: `${Math.min(100, amount / 2000)}%` }]} /></View>
            <Text style={styles.amount}>{formatMoney(amount, settings.baseCurrency)}</Text>
          </View>
        ))}
      </Card>

      <Card>
        <Text style={styles.cardTitle}>Все выплаты на 12 месяцев</Text>
        {flows.map(flow => <PaymentRow key={flow.id} flow={flow} />)}
        {flows.length === 0 ? <Text style={styles.muted}>Нет будущих выплат. Добавь актив с дивидендом или купоном.</Text> : null}
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  cardTitle: { fontSize: 18, fontWeight: '900', color: colors.text, marginBottom: 10 },
  muted: { color: colors.muted },
  monthRow: { marginBottom: 12 },
  month: { color: colors.text, fontWeight: '800', marginBottom: 6 },
  barWrap: { height: 10, backgroundColor: '#EEF2F7', borderRadius: 99, overflow: 'hidden' },
  bar: { height: 10, backgroundColor: colors.green, borderRadius: 99 },
  amount: { color: colors.muted, marginTop: 4 }
});
