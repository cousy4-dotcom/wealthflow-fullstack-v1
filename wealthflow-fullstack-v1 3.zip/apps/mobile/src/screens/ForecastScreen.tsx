import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Card } from '../components/Card';
import { MetricCard } from '../components/MetricCard';
import { Screen } from '../components/Screen';
import { forecastCapital, formatMoney, portfolioValue } from '../domain/finance';
import { useAppState } from '../state/AppState';
import { colors } from '../theme';

export function ForecastScreen() {
  const { assets, settings } = useAppState();
  const capital = portfolioValue(assets, settings.baseCurrency);
  const rows = forecastCapital(capital, settings);
  const last = rows.at(-1);

  return (
    <Screen title="Прогноз" subtitle="Расчет будущего капитала с учетом пополнений, реинвестирования, доходности и инфляции.">
      <View style={styles.grid}>
        <MetricCard label="Старт" value={formatMoney(capital, settings.baseCurrency)} />
        <MetricCard label={`Через ${settings.years} лет`} value={formatMoney(last?.nominalCapital ?? 0, settings.baseCurrency)} />
        <MetricCard label="Реально" value={formatMoney(last?.realCapital ?? 0, settings.baseCurrency)} hint="в сегодняшних деньгах" />
        <MetricCard label="Доход/мес." value={formatMoney(last?.monthlyIncome ?? 0, settings.baseCurrency)} />
      </View>

      <Card>
        <Text style={styles.cardTitle}>Динамика по годам</Text>
        {rows.map(row => {
          const width = last ? Math.max(6, (row.nominalCapital / last.nominalCapital) * 100) : 0;
          return (
            <View key={row.year} style={styles.yearRow}>
              <View style={styles.yearHeader}>
                <Text style={styles.year}>Год {row.year}</Text>
                <Text style={styles.value}>{formatMoney(row.nominalCapital, settings.baseCurrency)}</Text>
              </View>
              <View style={styles.barWrap}><View style={[styles.bar, { width: `${width}%` }]} /></View>
              <Text style={styles.muted}>Реально: {formatMoney(row.realCapital, settings.baseCurrency)} · Доход/мес: {formatMoney(row.monthlyIncome, settings.baseCurrency)}</Text>
            </View>
          );
        })}
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  cardTitle: { fontSize: 18, fontWeight: '900', color: colors.text, marginBottom: 10 },
  yearRow: { marginBottom: 16 },
  yearHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  year: { color: colors.text, fontWeight: '900' },
  value: { color: colors.text, fontWeight: '900' },
  barWrap: { height: 12, backgroundColor: '#EEF2F7', borderRadius: 99, overflow: 'hidden' },
  bar: { height: 12, backgroundColor: colors.blue, borderRadius: 99 },
  muted: { color: colors.muted, marginTop: 6, fontSize: 12 }
});
