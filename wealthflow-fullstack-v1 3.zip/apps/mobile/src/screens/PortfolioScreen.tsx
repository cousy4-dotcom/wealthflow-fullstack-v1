import React, { useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { AssetRow } from '../components/AssetRow';
import { Card } from '../components/Card';
import { Screen } from '../components/Screen';
import { formatMoney, portfolioValue } from '../domain/finance';
import { useAppState } from '../state/AppState';
import { colors } from '../theme';
import { Asset, AssetType } from '../types';

export function PortfolioScreen() {
  const { assets, settings, addAsset, removeAsset } = useAppState();
  const [name, setName] = useState('');
  const [ticker, setTicker] = useState('');
  const [type, setType] = useState<AssetType>('STOCK');
  const [quantity, setQuantity] = useState('');
  const [price, setPrice] = useState('');
  const [payment, setPayment] = useState('');

  const add = () => {
    const q = Number(quantity);
    const p = Number(price);
    if (!name || !q || !p) {
      Alert.alert('Проверь данные', 'Название, количество и цена обязательны.');
      return;
    }
    const asset: Asset = {
      id: String(Date.now()),
      name,
      ticker: ticker || undefined,
      type,
      currency: 'RUB',
      quantity: q,
      avgPrice: p,
      currentPrice: p,
      taxRate: 0.13,
      paymentFrequency: type === 'BOND' ? 'semiannual' : 'annual',
      nextPaymentDate: new Date(new Date().getFullYear() + 1, 0, 15).toISOString(),
      dividendPerShare: type === 'STOCK' ? Number(payment || 0) : undefined,
      couponAmount: type === 'BOND' ? Number(payment || 0) : undefined,
      nominalValue: type === 'BOND' ? 1000 : undefined
    };
    addAsset(asset);
    setName(''); setTicker(''); setQuantity(''); setPrice(''); setPayment('');
  };

  return (
    <Screen title="Портфель" subtitle="Добавляй акции, облигации, фонды и кэш. Данные сохраняются локально на устройстве.">
      <Card>
        <Text style={styles.cardTitle}>Стоимость портфеля</Text>
        <Text style={styles.big}>{formatMoney(portfolioValue(assets, settings.baseCurrency), settings.baseCurrency)}</Text>
      </Card>

      <Card>
        <Text style={styles.cardTitle}>Добавить актив</Text>
        <View style={styles.typeRow}>
          {(['STOCK', 'BOND', 'FUND', 'CASH'] as AssetType[]).map(item => (
            <Pressable key={item} onPress={() => setType(item)} style={[styles.typeButton, type === item && styles.activeType]}>
              <Text style={[styles.typeText, type === item && styles.activeTypeText]}>{item}</Text>
            </Pressable>
          ))}
        </View>
        <TextInput placeholder="Название" style={styles.input} value={name} onChangeText={setName} />
        <TextInput placeholder="Тикер" style={styles.input} value={ticker} onChangeText={setTicker} />
        <TextInput placeholder="Количество" keyboardType="decimal-pad" style={styles.input} value={quantity} onChangeText={setQuantity} />
        <TextInput placeholder="Текущая цена" keyboardType="decimal-pad" style={styles.input} value={price} onChangeText={setPrice} />
        <TextInput placeholder={type === 'BOND' ? 'Купон на 1 облигацию' : 'Дивиденд на 1 акцию'} keyboardType="decimal-pad" style={styles.input} value={payment} onChangeText={setPayment} />
        <Pressable style={styles.button} onPress={add}><Text style={styles.buttonText}>Добавить</Text></Pressable>
      </Card>

      <Card>
        <Text style={styles.cardTitle}>Активы</Text>
        {assets.map(asset => <AssetRow key={asset.id} asset={asset} baseCurrency={settings.baseCurrency} onRemove={() => removeAsset(asset.id)} />)}
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  cardTitle: { fontSize: 18, fontWeight: '900', color: colors.text, marginBottom: 10 },
  big: { fontSize: 26, fontWeight: '900', color: colors.text },
  input: { backgroundColor: '#F9FAFB', borderColor: colors.border, borderWidth: 1, borderRadius: 14, padding: 14, marginBottom: 10 },
  button: { backgroundColor: colors.primary, borderRadius: 14, padding: 15, alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: '900' },
  typeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 10 },
  typeButton: { borderWidth: 1, borderColor: colors.border, borderRadius: 999, paddingVertical: 8, paddingHorizontal: 12 },
  activeType: { backgroundColor: colors.primary, borderColor: colors.primary },
  typeText: { color: colors.text, fontWeight: '800' },
  activeTypeText: { color: '#fff' }
});
