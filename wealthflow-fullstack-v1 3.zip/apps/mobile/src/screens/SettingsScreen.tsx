import React from 'react';
import { Pressable, StyleSheet, Text, TextInput } from 'react-native';
import { Card } from '../components/Card';
import { Screen } from '../components/Screen';
import { useAppState } from '../state/AppState';
import { colors } from '../theme';

function pct(value: number) {
  return String(Math.round(value * 100));
}

export function SettingsScreen() {
  const { settings, updateSettings, resetDemo } = useAppState();

  return (
    <Screen title="Настройки" subtitle="Настрой сценарий прогноза: пополнения, доходность, инфляцию, реинвест и цели.">
      <Card>
        <Text style={styles.cardTitle}>Сценарий</Text>
        <Text style={styles.label}>Ежемесячное пополнение, ₽</Text>
        <TextInput style={styles.input} keyboardType="decimal-pad" value={String(settings.monthlyContribution)} onChangeText={v => updateSettings({ monthlyContribution: Number(v) || 0 })} />

        <Text style={styles.label}>Ожидаемая доходность, % годовых</Text>
        <TextInput style={styles.input} keyboardType="decimal-pad" value={pct(settings.annualReturn)} onChangeText={v => updateSettings({ annualReturn: (Number(v) || 0) / 100 })} />

        <Text style={styles.label}>Доходность cash flow, % годовых</Text>
        <TextInput style={styles.input} keyboardType="decimal-pad" value={pct(settings.incomeYield)} onChangeText={v => updateSettings({ incomeYield: (Number(v) || 0) / 100 })} />

        <Text style={styles.label}>Инфляция, % годовых</Text>
        <TextInput style={styles.input} keyboardType="decimal-pad" value={pct(settings.inflationRate)} onChangeText={v => updateSettings({ inflationRate: (Number(v) || 0) / 100 })} />

        <Text style={styles.label}>Реинвестирование, % выплат</Text>
        <TextInput style={styles.input} keyboardType="decimal-pad" value={pct(settings.reinvestmentRate)} onChangeText={v => updateSettings({ reinvestmentRate: Math.max(0, Math.min(1, (Number(v) || 0) / 100)) })} />

        <Text style={styles.label}>Горизонт, лет</Text>
        <TextInput style={styles.input} keyboardType="decimal-pad" value={String(settings.years)} onChangeText={v => updateSettings({ years: Math.max(1, Math.min(30, Number(v) || 1)) })} />
      </Card>

      <Card>
        <Text style={styles.cardTitle}>Цели</Text>
        <Text style={styles.label}>Целевой капитал</Text>
        <TextInput style={styles.input} keyboardType="decimal-pad" value={String(settings.targetCapital)} onChangeText={v => updateSettings({ targetCapital: Number(v) || 0 })} />
        <Text style={styles.label}>Целевой пассивный доход в месяц</Text>
        <TextInput style={styles.input} keyboardType="decimal-pad" value={String(settings.targetMonthlyIncome)} onChangeText={v => updateSettings({ targetMonthlyIncome: Number(v) || 0 })} />
      </Card>

      <Card>
        <Text style={styles.disclaimer}>Приложение не является индивидуальной инвестиционной рекомендацией. Все прогнозы являются оценочными и не гарантируют будущую доходность.</Text>
        <Pressable style={styles.reset} onPress={resetDemo}><Text style={styles.resetText}>Сбросить демо-данные</Text></Pressable>
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  cardTitle: { fontSize: 18, fontWeight: '900', color: colors.text, marginBottom: 12 },
  label: { color: colors.muted, marginBottom: 6, fontWeight: '700' },
  input: { backgroundColor: '#F9FAFB', borderColor: colors.border, borderWidth: 1, borderRadius: 14, padding: 14, marginBottom: 12 },
  disclaimer: { color: colors.muted, lineHeight: 20 },
  reset: { backgroundColor: colors.red, borderRadius: 14, padding: 14, alignItems: 'center', marginTop: 14 },
  resetText: { color: '#fff', fontWeight: '900' }
});
