export const colors = {
  bg: '#F4F5F7',
  card: '#FFFFFF',
  text: '#111827',
  muted: '#6B7280',
  border: '#E5E7EB',
  primary: '#101827',
  green: '#047857',
  red: '#B91C1C',
  amber: '#B45309',
  blue: '#1D4ED8',
  softGreen: '#ECFDF5',
  softBlue: '#EFF6FF',
  softAmber: '#FFFBEB'
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24
};
