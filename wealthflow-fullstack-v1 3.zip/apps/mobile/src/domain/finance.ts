import { Asset, CashFlow, Currency, ForecastRow, ForecastSettings } from '../types';

export const fxRates: Record<Currency, number> = {
  RUB: 1,
  USD: 90,
  EUR: 98,
  CNY: 12.5,
  GBP: 115,
  CHF: 102
};

export function formatMoney(value: number, currency: Currency = 'RUB') {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency,
    maximumFractionDigits: 0
  }).format(value || 0);
}

export function positionValue(asset: Asset, baseCurrency: Currency): number {
  const assetFx = fxRates[asset.currency] ?? 1;
  const baseFx = fxRates[baseCurrency] ?? 1;
  return asset.quantity * asset.currentPrice * (assetFx / baseFx);
}

export function portfolioValue(assets: Asset[], baseCurrency: Currency): number {
  return assets.reduce((sum, asset) => sum + positionValue(asset, baseCurrency), 0);
}

function addMonths(date: Date, months: number) {
  const next = new Date(date);
  next.setMonth(next.getMonth() + months);
  return next;
}

function frequencyMonths(frequency?: Asset['paymentFrequency']) {
  if (frequency === 'monthly') return 1;
  if (frequency === 'quarterly') return 3;
  if (frequency === 'semiannual') return 6;
  return 12;
}

export function generateCashFlows(assets: Asset[], months = 12): CashFlow[] {
  const from = new Date();
  const to = addMonths(from, months);
  const flows: CashFlow[] = [];

  assets.forEach(asset => {
    let cursor = asset.nextPaymentDate ? new Date(asset.nextPaymentDate) : null;
    const step = frequencyMonths(asset.paymentFrequency);
    const taxRate = Math.max(0, Math.min(1, asset.taxRate ?? 0));

    if (cursor && cursor < from) {
      while (cursor < from) cursor = addMonths(cursor, step);
    }

    while (cursor && cursor <= to) {
      if (['STOCK', 'FUND', 'ETF'].includes(asset.type)) {
        const gross = asset.quantity * (asset.dividendPerShare ?? 0);
        if (gross > 0) {
          flows.push({
            id: `${asset.id}-${cursor.toISOString()}-dividend`,
            assetId: asset.id,
            assetName: asset.name,
            date: cursor.toISOString(),
            type: 'DIVIDEND',
            grossAmount: gross,
            taxAmount: gross * taxRate,
            netAmount: gross * (1 - taxRate),
            currency: asset.currency
          });
        }
      }

      if (asset.type === 'BOND') {
        const gross = asset.quantity * (asset.couponAmount ?? 0);
        if (gross > 0) {
          flows.push({
            id: `${asset.id}-${cursor.toISOString()}-coupon`,
            assetId: asset.id,
            assetName: asset.name,
            date: cursor.toISOString(),
            type: 'COUPON',
            grossAmount: gross,
            taxAmount: gross * taxRate,
            netAmount: gross * (1 - taxRate),
            currency: asset.currency
          });
        }
      }

      cursor = addMonths(cursor, step);
    }

    if (asset.type === 'BOND' && asset.maturityDate) {
      const maturity = new Date(asset.maturityDate);
      if (maturity >= from && maturity <= to) {
        const gross = asset.quantity * (asset.nominalValue ?? 1000);
        flows.push({
          id: `${asset.id}-maturity`,
          assetId: asset.id,
          assetName: asset.name,
          date: maturity.toISOString(),
          type: 'MATURITY',
          grossAmount: gross,
          taxAmount: 0,
          netAmount: gross,
          currency: asset.currency
        });
      }
    }
  });

  return flows.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
}

export function forecastCapital(currentCapital: number, settings: ForecastSettings): ForecastRow[] {
  const rows: ForecastRow[] = [];
  const monthlyReturn = Math.pow(1 + settings.annualReturn, 1 / 12) - 1;
  let capital = currentCapital;
  let contributedTotal = 0;

  for (let month = 1; month <= settings.years * 12; month += 1) {
    capital += settings.monthlyContribution;
    contributedTotal += settings.monthlyContribution;

    const monthlyIncome = capital * (settings.incomeYield / 12);
    const reinvestedIncome = monthlyIncome * settings.reinvestmentRate;
    const marketGrowth = capital * monthlyReturn;
    capital += reinvestedIncome + marketGrowth;

    if (month % 12 === 0) {
      const year = month / 12;
      const annualIncome = capital * settings.incomeYield;
      rows.push({
        year,
        nominalCapital: Math.round(capital),
        realCapital: Math.round(capital / Math.pow(1 + settings.inflationRate, year)),
        annualIncome: Math.round(annualIncome),
        monthlyIncome: Math.round(annualIncome / 12),
        contributedTotal: Math.round(contributedTotal)
      });
    }
  }

  return rows;
}

export function concentrationRisk(assets: Asset[], baseCurrency: Currency) {
  const total = portfolioValue(assets, baseCurrency);
  if (total <= 0) return { level: 'low', maxWeight: 0, assetName: '—' };

  let maxWeight = 0;
  let assetName = '—';
  assets.forEach(asset => {
    const weight = positionValue(asset, baseCurrency) / total;
    if (weight > maxWeight) {
      maxWeight = weight;
      assetName = asset.name;
    }
  });

  return {
    level: maxWeight >= 0.35 ? 'high' : maxWeight >= 0.2 ? 'medium' : 'low',
    maxWeight: Math.round(maxWeight * 1000) / 10,
    assetName
  };
}

export function groupedIncomeByMonth(flows: CashFlow[], baseCurrency: Currency) {
  const result: Record<string, number> = {};
  flows.forEach(flow => {
    const d = new Date(flow.date);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    result[key] = (result[key] ?? 0) + flow.netAmount * ((fxRates[flow.currency] ?? 1) / (fxRates[baseCurrency] ?? 1));
  });
  return result;
}
