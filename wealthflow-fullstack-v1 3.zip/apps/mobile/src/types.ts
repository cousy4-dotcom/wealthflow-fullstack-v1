export type Currency = 'RUB' | 'USD' | 'EUR' | 'CNY' | 'GBP' | 'CHF';
export type AssetType = 'STOCK' | 'BOND' | 'FUND' | 'ETF' | 'CURRENCY' | 'CASH' | 'DEPOSIT' | 'CRYPTO' | 'OTHER';
export type CashFlowType = 'DIVIDEND' | 'COUPON' | 'MATURITY' | 'AMORTIZATION' | 'DEPOSIT_INTEREST' | 'MANUAL';

export type Asset = {
  id: string;
  name: string;
  ticker?: string;
  type: AssetType;
  currency: Currency;
  quantity: number;
  avgPrice: number;
  currentPrice: number;
  dividendPerShare?: number;
  couponAmount?: number;
  nominalValue?: number;
  taxRate: number;
  paymentFrequency?: 'monthly' | 'quarterly' | 'semiannual' | 'annual';
  nextPaymentDate?: string;
  maturityDate?: string;
  sector?: string;
  issuer?: string;
};

export type CashFlow = {
  id: string;
  assetId?: string;
  assetName: string;
  date: string;
  type: CashFlowType;
  grossAmount: number;
  taxAmount: number;
  netAmount: number;
  currency: Currency;
};

export type ForecastSettings = {
  baseCurrency: Currency;
  monthlyContribution: number;
  annualReturn: number;
  incomeYield: number;
  inflationRate: number;
  reinvestmentRate: number;
  years: number;
  targetCapital: number;
  targetMonthlyIncome: number;
};

export type ForecastRow = {
  year: number;
  nominalCapital: number;
  realCapital: number;
  annualIncome: number;
  monthlyIncome: number;
  contributedTotal: number;
};
