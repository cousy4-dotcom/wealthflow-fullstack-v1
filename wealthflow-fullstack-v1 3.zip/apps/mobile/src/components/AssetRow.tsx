import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { positionValue, formatMoney } from '../domain/finance';
import { colors } from '../theme';
import { Asset, Currency } from '../types';

export function AssetRow({ asset, baseCurrency, onRemove }: { asset: Asset; baseCurrency: Currency; onRemove: () => void }) {
  const value = positionValue(asset, baseCurrency);
  return (
    <View style={styles.row}>
      <View style={{ flex: 1 }}>
        <Text style={styles.name}>{asset.name}</Text>
        <Text style={styles.meta}>{asset.ticker ?? asset.type} · {asset.quantity} шт. · {asset.currency}</Text>
      </View>
      <View style={styles.right}>
        <Text style={styles.value}>{formatMoney(value, baseCurrency)}</Text>
        <Pressable onPress={onRemove}><Text style={styles.remove}>Удалить</Text></Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', borderBottomWidth: 1, borderColor: colors.border, paddingVertical: 12 },
  name: { color: colors.text, fontWeight: '800', fontSize: 16 },
  meta: { color: colors.muted, marginTop: 3 },
  right: { alignItems: 'flex-end', marginLeft: 12 },
  value: { color: colors.text, fontWeight: '800' },
  remove: { color: colors.red, fontSize: 12, marginTop: 6 }
});
