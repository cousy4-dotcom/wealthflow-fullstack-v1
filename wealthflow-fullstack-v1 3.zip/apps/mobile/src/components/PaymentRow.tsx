import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { formatMoney } from '../domain/finance';
import { colors } from '../theme';
import { CashFlow } from '../types';

const typeLabel: Record<string, string> = {
  DIVIDEND: 'Дивиденд',
  COUPON: 'Купон',
  MATURITY: 'Погашение',
  AMORTIZATION: 'Амортизация',
  MANUAL: 'Ручной поток',
  DEPOSIT_INTEREST: 'Проценты'
};

export function PaymentRow({ flow }: { flow: CashFlow }) {
  const date = new Date(flow.date).toLocaleDateString('ru-RU', { day: '2-digit', month: 'short', year: 'numeric' });
  return (
    <View style={styles.row}>
      <View style={{ flex: 1 }}>
        <Text style={styles.name}>{flow.assetName}</Text>
        <Text style={styles.meta}>{date} · {typeLabel[flow.type] ?? flow.type}</Text>
      </View>
      <View style={styles.amountBox}>
        <Text style={styles.amount}>{formatMoney(flow.netAmount, flow.currency)}</Text>
        <Text style={styles.tax}>налог {formatMoney(flow.taxAmount, flow.currency)}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderColor: colors.border },
  name: { fontWeight: '800', color: colors.text },
  meta: { color: colors.muted, marginTop: 4 },
  amountBox: { alignItems: 'flex-end', marginLeft: 8 },
  amount: { fontWeight: '900', color: colors.green },
  tax: { color: colors.muted, fontSize: 12, marginTop: 3 }
});
