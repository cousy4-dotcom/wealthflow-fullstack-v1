import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme';
import { Card } from './Card';

export function MetricCard({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <Card style={styles.card}>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.value}>{value}</Text>
      {hint ? <Text style={styles.hint}>{hint}</Text> : null}
    </Card>
  );
}

const styles = StyleSheet.create({
  card: { flex: 1, minWidth: '47%' },
  label: { color: colors.muted, fontSize: 12, marginBottom: 6 },
  value: { color: colors.text, fontWeight: '800', fontSize: 20 },
  hint: { color: colors.muted, fontSize: 12, marginTop: 6 }
});
