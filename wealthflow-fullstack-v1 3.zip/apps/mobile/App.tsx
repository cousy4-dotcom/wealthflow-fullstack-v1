import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AppStateProvider } from './src/state/AppState';
import { WealthFlowApp } from './src/WealthFlowApp';

export default function App() {
  return (
    <SafeAreaProvider>
      <AppStateProvider>
        <WealthFlowApp />
        <StatusBar style="dark" />
      </AppStateProvider>
    </SafeAreaProvider>
  );
}
