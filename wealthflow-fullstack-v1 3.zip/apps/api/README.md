# WealthFlow API

Fastify API for WealthFlow.

## Start

```bash
cp .env.example .env
npm install
npm run db:up
npm run prisma:generate
npm run prisma:migrate
npm run dev
```

## Docs

```text
http://localhost:4000/docs
```
