import type { FastifyReply, FastifyRequest } from 'fastify';

export async function authGuard(request: FastifyRequest, reply: FastifyReply) {
  try {
    await request.jwtVerify();
  } catch {
    return reply.status(401).send({ message: 'Unauthorized' });
  }
}

export function userIdFromRequest(request: FastifyRequest): string {
  const user = request.user as { sub?: string } | undefined;
  if (!user?.sub) throw new Error('User id is missing in token');
  return user.sub;
}
