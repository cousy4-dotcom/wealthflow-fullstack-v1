import Fastify from 'fastify';
import cors from '@fastify/cors';
import jwt from '@fastify/jwt';
import swagger from '@fastify/swagger';
import swaggerUi from '@fastify/swagger-ui';
import { config } from './config.js';
import { authRoutes } from './modules/auth.routes.js';
import { portfolioRoutes } from './modules/portfolio.routes.js';
import { assetRoutes } from './modules/asset.routes.js';
import { cashflowRoutes } from './modules/cashflow.routes.js';
import { forecastRoutes } from './modules/forecast.routes.js';
import { reportRoutes } from './modules/report.routes.js';

const app = Fastify({ logger: true });

await app.register(cors, { origin: config.corsOrigin });
await app.register(jwt, { secret: config.jwtSecret });
await app.register(swagger, {
  openapi: {
    info: {
      title: 'WealthFlow API',
      version: '1.0.0'
    }
  }
});
await app.register(swaggerUi, { routePrefix: '/docs' });

app.get('/health', async () => ({ ok: true, service: 'wealthflow-api', time: new Date().toISOString() }));

await app.register(authRoutes);
await app.register(portfolioRoutes);
await app.register(assetRoutes);
await app.register(cashflowRoutes);
await app.register(forecastRoutes);
await app.register(reportRoutes);

app.setErrorHandler((error, _request, reply) => {
  app.log.error(error);
  const statusCode = error.validation ? 400 : 500;
  reply.status(statusCode).send({
    message: statusCode === 400 ? 'Validation error' : error.message,
    details: error.validation ?? undefined
  });
});

await app.listen({ port: config.port, host: '0.0.0.0' });
