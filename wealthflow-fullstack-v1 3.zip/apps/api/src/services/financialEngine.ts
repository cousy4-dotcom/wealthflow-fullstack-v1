export type Currency = 'RUB' | 'USD' | 'EUR' | 'CNY' | 'GBP' | 'CHF';
export type AssetType = 'STOCK' | 'BOND' | 'FUND' | 'ETF' | 'CURRENCY' | 'CASH' | 'DEPOSIT' | 'CRYPTO' | 'OTHER';
export type CashFlowType = 'DIVIDEND' | 'COUPON' | 'MATURITY' | 'AMORTIZATION' | 'DEPOSIT_INTEREST' | 'MANUAL';

export type AssetInput = {
  id: string;
  name: string;
  ticker?: string | null;
  assetType: AssetType;
  currency: Currency;
  quantity: number;
  avgPrice: number;
  currentPrice: number;
  dividendPerShare?: number | null;
  couponAmount?: number | null;
  nominalValue?: number | null;
  taxRate: number;
  paymentFrequency?: string | null;
  nextPaymentDate?: Date | string | null;
  maturityDate?: Date | string | null;
  sector?: string | null;
  issuer?: string | null;
};

export type FxRates = Record<Currency, number>;

export type ForecastParams = {
  currentCapital: number;
  monthlyContribution: number;
  annualReturn: number;
  incomeYield: number;
  inflationRate: number;
  reinvestmentRate: number;
  years: number;
  contributionIndexation?: number;
};

export type ForecastYear = {
  year: number;
  nominalCapital: number;
  realCapital: number;
  annualIncome: number;
  monthlyIncome: number;
  contributedTotal: number;
  taxesEstimate: number;
};

export function toNumber(value: unknown, fallback = 0): number {
  if (value === null || value === undefined) return fallback;
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function positionValue(asset: AssetInput, fxRates: FxRates, baseCurrency: Currency): number {
  const assetFx = fxRates[asset.currency] ?? 1;
  const baseFx = fxRates[baseCurrency] ?? 1;
  const fxToBase = assetFx / baseFx;
  return asset.quantity * asset.currentPrice * fxToBase;
}

export function portfolioValue(assets: AssetInput[], fxRates: FxRates, baseCurrency: Currency): number {
  return assets.reduce((sum, asset) => sum + positionValue(asset, fxRates, baseCurrency), 0);
}

function addMonths(date: Date, months: number): Date {
  const result = new Date(date);
  result.setMonth(result.getMonth() + months);
  return result;
}

function frequencyToMonths(frequency?: string | null): number {
  switch ((frequency ?? 'annual').toLowerCase()) {
    case 'monthly': return 1;
    case 'quarterly': return 3;
    case 'semiannual': return 6;
    case 'annual': return 12;
    default: return 12;
  }
}

export function generateCashFlows(assets: AssetInput[], from: Date, to: Date) {
  const result: Array<{
    assetId: string;
    assetName: string;
    date: Date;
    type: CashFlowType;
    grossAmount: number;
    taxAmount: number;
    netAmount: number;
    currency: Currency;
    note: string;
  }> = [];

  for (const asset of assets) {
    const taxRate = Math.max(0, Math.min(1, asset.taxRate ?? 0));
    const monthsStep = frequencyToMonths(asset.paymentFrequency);
    let cursor = asset.nextPaymentDate ? new Date(asset.nextPaymentDate) : null;

    if (cursor && cursor < from) {
      while (cursor < from) cursor = addMonths(cursor, monthsStep);
    }

    while (cursor && cursor <= to) {
      if (asset.assetType === 'STOCK' || asset.assetType === 'FUND' || asset.assetType === 'ETF') {
        const gross = asset.quantity * toNumber(asset.dividendPerShare);
        if (gross > 0) {
          const tax = gross * taxRate;
          result.push({
            assetId: asset.id,
            assetName: asset.name,
            date: new Date(cursor),
            type: 'DIVIDEND',
            grossAmount: gross,
            taxAmount: tax,
            netAmount: gross - tax,
            currency: asset.currency,
            note: `Дивиденд ${asset.ticker ?? asset.name}`
          });
        }
      }

      if (asset.assetType === 'BOND') {
        const gross = asset.quantity * toNumber(asset.couponAmount);
        if (gross > 0) {
          const tax = gross * taxRate;
          result.push({
            assetId: asset.id,
            assetName: asset.name,
            date: new Date(cursor),
            type: 'COUPON',
            grossAmount: gross,
            taxAmount: tax,
            netAmount: gross - tax,
            currency: asset.currency,
            note: `Купон ${asset.ticker ?? asset.name}`
          });
        }
      }

      cursor = addMonths(cursor, monthsStep);
    }

    if (asset.assetType === 'BOND' && asset.maturityDate) {
      const maturity = new Date(asset.maturityDate);
      if (maturity >= from && maturity <= to) {
        const gross = asset.quantity * toNumber(asset.nominalValue, 1000);
        result.push({
          assetId: asset.id,
          assetName: asset.name,
          date: maturity,
          type: 'MATURITY',
          grossAmount: gross,
          taxAmount: 0,
          netAmount: gross,
          currency: asset.currency,
          note: `Погашение ${asset.ticker ?? asset.name}`
        });
      }
    }
  }

  return result.sort((a, b) => a.date.getTime() - b.date.getTime());
}

export function forecastCapital(params: ForecastParams): ForecastYear[] {
  const years = Math.max(1, Math.min(50, Math.floor(params.years)));
  const monthlyReturn = Math.pow(1 + params.annualReturn, 1 / 12) - 1;
  const monthlyInflation = Math.pow(1 + params.inflationRate, 1 / 12) - 1;
  let capital = params.currentCapital;
  let monthlyContribution = params.monthlyContribution;
  let contributedTotal = 0;
  const rows: ForecastYear[] = [];

  for (let month = 1; month <= years * 12; month++) {
    capital += monthlyContribution;
    contributedTotal += monthlyContribution;

    const income = capital * (params.incomeYield / 12);
    const reinvestedIncome = income * params.reinvestmentRate;
    const marketGrowth = capital * monthlyReturn;

    capital += reinvestedIncome + marketGrowth;

    if (month % 12 === 0) {
      const year = month / 12;
      const annualIncome = capital * params.incomeYield;
      const realCapital = capital / Math.pow(1 + params.inflationRate, year);
      rows.push({
        year,
        nominalCapital: Math.round(capital),
        realCapital: Math.round(realCapital),
        annualIncome: Math.round(annualIncome),
        monthlyIncome: Math.round(annualIncome / 12),
        contributedTotal: Math.round(contributedTotal),
        taxesEstimate: Math.round(annualIncome * 0.13)
      });

      monthlyContribution *= 1 + (params.contributionIndexation ?? 0);
    }
  }

  return rows;
}

export function riskSummary(assets: AssetInput[], fxRates: FxRates, baseCurrency: Currency) {
  const total = portfolioValue(assets, fxRates, baseCurrency);
  if (total <= 0) {
    return { total, maxAssetWeight: 0, maxAssetName: null, byType: {}, byCurrency: {}, concentrationLevel: 'low' };
  }

  const byType: Record<string, number> = {};
  const byCurrency: Record<string, number> = {};
  let maxAssetWeight = 0;
  let maxAssetName: string | null = null;

  for (const asset of assets) {
    const value = positionValue(asset, fxRates, baseCurrency);
    const weight = value / total;
    byType[asset.assetType] = (byType[asset.assetType] ?? 0) + value;
    byCurrency[asset.currency] = (byCurrency[asset.currency] ?? 0) + value;
    if (weight > maxAssetWeight) {
      maxAssetWeight = weight;
      maxAssetName = asset.name;
    }
  }

  const concentrationLevel = maxAssetWeight >= 0.35 ? 'high' : maxAssetWeight >= 0.2 ? 'medium' : 'low';

  return {
    total: Math.round(total),
    maxAssetWeight: Math.round(maxAssetWeight * 10000) / 100,
    maxAssetName,
    byType,
    byCurrency,
    concentrationLevel
  };
}
