import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { prisma } from '../db.js';
import { authGuard, userIdFromRequest } from '../middleware/auth.js';

const assetSchema = z.object({
  ticker: z.string().optional(),
  isin: z.string().optional(),
  name: z.string().min(1),
  assetType: z.enum(['STOCK', 'BOND', 'FUND', 'ETF', 'CURRENCY', 'CASH', 'DEPOSIT', 'CRYPTO', 'OTHER']),
  currency: z.enum(['RUB', 'USD', 'EUR', 'CNY', 'GBP', 'CHF']).default('RUB'),
  country: z.string().optional(),
  sector: z.string().optional(),
  issuer: z.string().optional(),
  quantity: z.number().nonnegative(),
  avgPrice: z.number().nonnegative(),
  currentPrice: z.number().nonnegative(),
  dividendPerShare: z.number().nonnegative().optional(),
  couponAmount: z.number().nonnegative().optional(),
  nominalValue: z.number().positive().optional(),
  taxRate: z.number().min(0).max(1).default(0.13),
  paymentFrequency: z.enum(['monthly', 'quarterly', 'semiannual', 'annual']).optional(),
  nextPaymentDate: z.string().datetime().optional(),
  maturityDate: z.string().datetime().optional(),
  riskLevel: z.string().optional(),
  liquidityLevel: z.string().optional(),
  userComment: z.string().optional()
});

async function assertPortfolioOwner(portfolioId: string, userId: string) {
  const portfolio = await prisma.portfolio.findFirst({ where: { id: portfolioId, userId } });
  if (!portfolio) throw new Error('Portfolio not found');
  return portfolio;
}

export async function assetRoutes(app: FastifyInstance) {
  app.addHook('preHandler', authGuard);

  app.get('/portfolios/:portfolioId/assets', async (request) => {
    const userId = userIdFromRequest(request);
    const { portfolioId } = request.params as { portfolioId: string };
    await assertPortfolioOwner(portfolioId, userId);
    const assets = await prisma.asset.findMany({ where: { portfolioId }, orderBy: { createdAt: 'asc' } });
    return { assets };
  });

  app.post('/portfolios/:portfolioId/assets', async (request, reply) => {
    const userId = userIdFromRequest(request);
    const { portfolioId } = request.params as { portfolioId: string };
    await assertPortfolioOwner(portfolioId, userId);
    const body = assetSchema.parse(request.body);
    const asset = await prisma.asset.create({
      data: {
        ...body,
        portfolioId,
        nextPaymentDate: body.nextPaymentDate ? new Date(body.nextPaymentDate) : undefined,
        maturityDate: body.maturityDate ? new Date(body.maturityDate) : undefined
      }
    });
    return reply.status(201).send({ asset });
  });

  app.put('/assets/:assetId', async (request) => {
    const userId = userIdFromRequest(request);
    const { assetId } = request.params as { assetId: string };
    const body = assetSchema.partial().parse(request.body);
    const existing = await prisma.asset.findUnique({ where: { id: assetId }, include: { portfolio: true } });
    if (!existing || existing.portfolio.userId !== userId) throw new Error('Asset not found');
    const asset = await prisma.asset.update({
      where: { id: assetId },
      data: {
        ...body,
        nextPaymentDate: body.nextPaymentDate ? new Date(body.nextPaymentDate) : undefined,
        maturityDate: body.maturityDate ? new Date(body.maturityDate) : undefined
      }
    });
    return { asset };
  });

  app.delete('/assets/:assetId', async (request) => {
    const userId = userIdFromRequest(request);
    const { assetId } = request.params as { assetId: string };
    const existing = await prisma.asset.findUnique({ where: { id: assetId }, include: { portfolio: true } });
    if (!existing || existing.portfolio.userId !== userId) throw new Error('Asset not found');
    await prisma.asset.delete({ where: { id: assetId } });
    return { ok: true };
  });
}
