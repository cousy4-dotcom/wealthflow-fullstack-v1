import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { prisma } from '../db.js';
import { authGuard, userIdFromRequest } from '../middleware/auth.js';
import { forecastCapital, portfolioValue, type AssetInput, type FxRates } from '../services/financialEngine.js';

const fxRates: FxRates = { RUB: 1, USD: 90, EUR: 98, CNY: 12.5, GBP: 115, CHF: 102 };

const forecastSchema = z.object({
  monthlyContribution: z.number().nonnegative().default(70000),
  annualReturn: z.number().min(-0.9).max(3).default(0.1),
  incomeYield: z.number().min(0).max(1).default(0.08),
  inflationRate: z.number().min(0).max(1).default(0.06),
  reinvestmentRate: z.number().min(0).max(1).default(1),
  years: z.number().int().min(1).max(50).default(10),
  contributionIndexation: z.number().min(0).max(1).default(0)
});

function mapAsset(asset: any): AssetInput {
  return {
    id: asset.id,
    name: asset.name,
    ticker: asset.ticker,
    assetType: asset.assetType,
    currency: asset.currency,
    quantity: Number(asset.quantity),
    avgPrice: Number(asset.avgPrice),
    currentPrice: Number(asset.currentPrice),
    dividendPerShare: Number(asset.dividendPerShare ?? 0),
    couponAmount: Number(asset.couponAmount ?? 0),
    nominalValue: Number(asset.nominalValue ?? 1000),
    taxRate: Number(asset.taxRate ?? 0.13),
    paymentFrequency: asset.paymentFrequency,
    nextPaymentDate: asset.nextPaymentDate,
    maturityDate: asset.maturityDate
  };
}

export async function forecastRoutes(app: FastifyInstance) {
  app.addHook('preHandler', authGuard);

  app.post('/portfolios/:portfolioId/forecast', async (request) => {
    const userId = userIdFromRequest(request);
    const { portfolioId } = request.params as { portfolioId: string };
    const body = forecastSchema.parse(request.body);
    const portfolio = await prisma.portfolio.findFirst({ where: { id: portfolioId, userId }, include: { assets: true } });
    if (!portfolio) throw new Error('Portfolio not found');
    const currentCapital = portfolioValue(portfolio.assets.map(mapAsset), fxRates, portfolio.baseCurrency as any);
    const forecast = forecastCapital({ currentCapital, ...body });
    return { currentCapital: Math.round(currentCapital), forecast };
  });
}
