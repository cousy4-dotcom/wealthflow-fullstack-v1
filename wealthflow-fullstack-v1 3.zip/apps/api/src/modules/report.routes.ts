import type { FastifyInstance } from 'fastify';
import { prisma } from '../db.js';
import { authGuard, userIdFromRequest } from '../middleware/auth.js';

export async function reportRoutes(app: FastifyInstance) {
  app.addHook('preHandler', authGuard);

  app.get('/portfolios/:portfolioId/reports/summary', async (request) => {
    const userId = userIdFromRequest(request);
    const { portfolioId } = request.params as { portfolioId: string };
    const portfolio = await prisma.portfolio.findFirst({
      where: { id: portfolioId, userId },
      include: { assets: true, cashFlows: { orderBy: { date: 'asc' } } }
    });
    if (!portfolio) throw new Error('Portfolio not found');

    return {
      reportType: 'portfolio-summary',
      generatedAt: new Date().toISOString(),
      portfolio: {
        id: portfolio.id,
        name: portfolio.name,
        baseCurrency: portfolio.baseCurrency
      },
      assets: portfolio.assets,
      cashFlows: portfolio.cashFlows,
      disclaimer: 'Расчеты являются оценочными и не являются индивидуальной инвестиционной рекомендацией.'
    };
  });
}
