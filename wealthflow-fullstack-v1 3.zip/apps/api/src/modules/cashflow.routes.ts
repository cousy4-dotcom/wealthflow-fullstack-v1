import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { prisma } from '../db.js';
import { authGuard, userIdFromRequest } from '../middleware/auth.js';
import { generateCashFlows, type AssetInput } from '../services/financialEngine.js';

const cashFlowSchema = z.object({
  assetId: z.string().optional(),
  date: z.string().datetime(),
  type: z.enum(['DIVIDEND', 'COUPON', 'MATURITY', 'AMORTIZATION', 'DEPOSIT_INTEREST', 'MANUAL']),
  grossAmount: z.number(),
  taxAmount: z.number().default(0),
  netAmount: z.number(),
  currency: z.enum(['RUB', 'USD', 'EUR', 'CNY', 'GBP', 'CHF']).default('RUB'),
  status: z.enum(['FORECAST', 'PLANNED', 'PAID', 'CANCELLED']).default('FORECAST'),
  note: z.string().optional()
});

function mapAsset(asset: any): AssetInput {
  return {
    id: asset.id,
    name: asset.name,
    ticker: asset.ticker,
    assetType: asset.assetType,
    currency: asset.currency,
    quantity: Number(asset.quantity),
    avgPrice: Number(asset.avgPrice),
    currentPrice: Number(asset.currentPrice),
    dividendPerShare: Number(asset.dividendPerShare ?? 0),
    couponAmount: Number(asset.couponAmount ?? 0),
    nominalValue: Number(asset.nominalValue ?? 1000),
    taxRate: Number(asset.taxRate ?? 0.13),
    paymentFrequency: asset.paymentFrequency,
    nextPaymentDate: asset.nextPaymentDate,
    maturityDate: asset.maturityDate
  };
}

export async function cashflowRoutes(app: FastifyInstance) {
  app.addHook('preHandler', authGuard);

  app.get('/portfolios/:portfolioId/cashflows', async (request) => {
    const userId = userIdFromRequest(request);
    const { portfolioId } = request.params as { portfolioId: string };
    const query = request.query as { from?: string; to?: string; regenerate?: string };
    const portfolio = await prisma.portfolio.findFirst({ where: { id: portfolioId, userId }, include: { assets: true } });
    if (!portfolio) throw new Error('Portfolio not found');

    const from = query.from ? new Date(query.from) : new Date();
    const to = query.to ? new Date(query.to) : new Date(new Date().setFullYear(new Date().getFullYear() + 1));

    if (query.regenerate === 'true') {
      const generated = generateCashFlows(portfolio.assets.map(mapAsset), from, to);
      return { cashFlows: generated };
    }

    const cashFlows = await prisma.cashFlow.findMany({
      where: { portfolioId, date: { gte: from, lte: to } },
      orderBy: { date: 'asc' }
    });
    return { cashFlows };
  });

  app.post('/portfolios/:portfolioId/cashflows', async (request, reply) => {
    const userId = userIdFromRequest(request);
    const { portfolioId } = request.params as { portfolioId: string };
    const body = cashFlowSchema.parse(request.body);
    const portfolio = await prisma.portfolio.findFirst({ where: { id: portfolioId, userId } });
    if (!portfolio) throw new Error('Portfolio not found');

    const cashFlow = await prisma.cashFlow.create({
      data: { ...body, portfolioId, date: new Date(body.date) }
    });
    return reply.status(201).send({ cashFlow });
  });
}
