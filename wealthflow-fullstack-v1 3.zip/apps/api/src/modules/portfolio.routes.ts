import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { prisma } from '../db.js';
import { authGuard, userIdFromRequest } from '../middleware/auth.js';
import { portfolioValue, riskSummary, type AssetInput, type FxRates } from '../services/financialEngine.js';

const createPortfolioSchema = z.object({
  name: z.string().min(1),
  baseCurrency: z.enum(['RUB', 'USD', 'EUR', 'CNY', 'GBP', 'CHF']).default('RUB')
});

const fxRates: FxRates = { RUB: 1, USD: 90, EUR: 98, CNY: 12.5, GBP: 115, CHF: 102 };

function mapAsset(asset: any): AssetInput {
  return {
    id: asset.id,
    name: asset.name,
    ticker: asset.ticker,
    assetType: asset.assetType,
    currency: asset.currency,
    quantity: Number(asset.quantity),
    avgPrice: Number(asset.avgPrice),
    currentPrice: Number(asset.currentPrice),
    dividendPerShare: Number(asset.dividendPerShare ?? 0),
    couponAmount: Number(asset.couponAmount ?? 0),
    nominalValue: Number(asset.nominalValue ?? 1000),
    taxRate: Number(asset.taxRate ?? 0.13),
    paymentFrequency: asset.paymentFrequency,
    nextPaymentDate: asset.nextPaymentDate,
    maturityDate: asset.maturityDate,
    sector: asset.sector,
    issuer: asset.issuer
  };
}

export async function portfolioRoutes(app: FastifyInstance) {
  app.addHook('preHandler', authGuard);

  app.get('/portfolios', async (request) => {
    const userId = userIdFromRequest(request);
    const portfolios = await prisma.portfolio.findMany({
      where: { userId },
      orderBy: { createdAt: 'asc' }
    });
    return { portfolios };
  });

  app.post('/portfolios', async (request) => {
    const userId = userIdFromRequest(request);
    const body = createPortfolioSchema.parse(request.body);
    const portfolio = await prisma.portfolio.create({ data: { ...body, userId } });
    return { portfolio };
  });

  app.get('/portfolios/:portfolioId/dashboard', async (request) => {
    const { portfolioId } = request.params as { portfolioId: string };
    const userId = userIdFromRequest(request);
    const portfolio = await prisma.portfolio.findFirst({
      where: { id: portfolioId, userId },
      include: { assets: true, cashFlows: { orderBy: { date: 'asc' }, take: 10 } }
    });
    if (!portfolio) return { message: 'Portfolio not found' };

    const assets = portfolio.assets.map(mapAsset);
    const total = portfolioValue(assets, fxRates, portfolio.baseCurrency as any);
    const risk = riskSummary(assets, fxRates, portfolio.baseCurrency as any);
    return {
      portfolio: { id: portfolio.id, name: portfolio.name, baseCurrency: portfolio.baseCurrency },
      summary: {
        totalCapital: Math.round(total),
        assetsCount: assets.length,
        risk,
        nextCashFlows: portfolio.cashFlows
      }
    };
  });
}
