import { describe, expect, it } from 'vitest';
import { forecastCapital, generateCashFlows, portfolioValue } from '../src/services/financialEngine.js';

describe('financialEngine', () => {
  it('calculates portfolio value in base currency', () => {
    const value = portfolioValue([
      { id: '1', name: 'Stock', assetType: 'STOCK', currency: 'RUB', quantity: 10, avgPrice: 90, currentPrice: 100, taxRate: 0.13 }
    ], { RUB: 1, USD: 90, EUR: 100, CNY: 12, GBP: 115, CHF: 102 }, 'RUB');
    expect(value).toBe(1000);
  });

  it('generates dividend cashflows', () => {
    const flows = generateCashFlows([
      { id: '1', name: 'Dividend Stock', assetType: 'STOCK', currency: 'RUB', quantity: 100, avgPrice: 100, currentPrice: 120, dividendPerShare: 10, taxRate: 0.13, paymentFrequency: 'annual', nextPaymentDate: '2026-01-15' }
    ], new Date('2026-01-01'), new Date('2026-12-31'));
    expect(flows).toHaveLength(1);
    expect(flows[0].netAmount).toBe(870);
  });

  it('forecasts capital for 10 years', () => {
    const forecast = forecastCapital({ currentCapital: 7_200_000, monthlyContribution: 70_000, annualReturn: 0.1, incomeYield: 0.08, inflationRate: 0.06, reinvestmentRate: 1, years: 10 });
    expect(forecast).toHaveLength(10);
    expect(forecast[9].nominalCapital).toBeGreaterThan(7_200_000);
  });
});
